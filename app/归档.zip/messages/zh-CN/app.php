<?php
return [
    // 操作
    'Create' => '创建',
    'Update' => '更新',
    'Delete' => '删除',

    'Agents' => '代理',
    'Customers' => '大C',
    'Orders' => '订单'
];