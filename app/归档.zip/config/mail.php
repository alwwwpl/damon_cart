<?php 
return [
    'class' => 'yii\swiftmailer\Mailer',
    'transport' => [
        'class' => 'Swift_SmtpTransport',
        'host' => 'smtp.exmail.qq.com',
        'username' => 'service@iddmall.com',
        'password' => 'dmg13579',
        'port' => 25,
        'encryption' => 'service@iddmall.com',
    ],
];