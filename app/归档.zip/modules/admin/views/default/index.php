<?php 
$this->title = "首页";
?>