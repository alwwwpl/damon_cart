<?php

namespace app\modules\agent\controllers;

use Yii;

use yii\web\Controller;

use app\models\InviteCode;
use app\models\search\InviteCodeSearch;

class ShareController extends Controller
{
    public function actionIndex()
    {
        $agent = Yii::$app->agent->identity;
        $count = $agent->getInviteCodes()->count();
        if($count>0){
            $searchModel = new InviteCodeSearch();
            $searchModel->agent_id = $agent->agent_id;
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

            return $this->render('index', [
                'count' => $count,
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
            ]);
        }

        return $this->render('index', ['count' => $count]);
    }

    public function actionGenCodes()
    {
        $agent = Yii::$app->agent->identity;
        for($i = 0; $i<500; $i++){
            $inviteCode = new InviteCode;
            $inviteCode->agent_id = $agent->agent_id;
            $inviteCode->save();
        }

        $this->redirect(['index']);
    }
}
