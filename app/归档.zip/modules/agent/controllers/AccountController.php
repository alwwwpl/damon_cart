<?php

namespace app\modules\agent\controllers;

use Yii;

use yii\web\Controller;

use app\models\Agent;
use app\models\InviteCode;

use app\modules\agent\models\LoginForm;
use app\modules\agent\models\FindPasswordForm;
use app\modules\agent\models\ResetPasswordForm;

class AccountController extends Controller
{
    public function actionCreate()
    {
        $code = Yii::$app->request->get('code');
        if(!$code){
            Yii::$app->session->setFlash('error', '没有邀请码不能注册');

            return $this->redirect(['default/index']);
        }

        $inviteCode = InviteCode::findOne(['code' => $code]);
        if(!$inviteCode){
            Yii::$app->session->setFlash('error', '没有邀请码不能注册');

            return $this->redirect(['default/index']);
        }

        if($inviteCode->status!=InviteCode::STATUS_UNUSED){
            Yii::$app->session->setFlash('error', '邀请码已经失效');

            return $this->redirect(['default/index']);
        }

        $agent = $inviteCode->agent;

        $model = new Agent();
        $model->parent_id = $agent->agent_id;
        $model->type = Agent::TYPE_CITY;
        $model->agent_province_id = $agent->agent_province_id;

        if ($model->load(Yii::$app->request->post())) {
            $image1 = $model->uploadImage1();
            $image2 = $model->uploadImage2();
 
            if ($model->save()) {
                if ($image1 !== false) {
                    $path1 = $model->getFile1();
                    $image1->saveAs($path1);
                }
                if ($image2 !== false) {
                    $path2 = $model->getFile2();
                    $image2->saveAs($path2);
                }

                $inviteCode->status = InviteCode::STATUS_USED;
                $inviteCode->save();

                Yii::$app->session->setFlash('success', '注册成功，等待后台审核');

                return $this->redirect(['default/index']);
            }
        }

        $this->layout = 'register';
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    public function actionLogin()
    {
        $model = new LoginForm();
        
        if($model->load(Yii::$app->request->post())){

            if($model->login()){
                return $this->redirect('/agent/');
            } else {
                return $this->render('login',['model'=>$model]);
            }
        }

        $this->layout = "main-login";

        return $this->render('login',['model'=>$model]);

    }

    public function actionLogout()
    {
        Yii::$app->agent->logout();

        return $this->redirect(array('/agent/account/login'));
    }

    public function actionFindPassword()
    {
        $model = new FindPasswordForm();
        
        if($model->load(Yii::$app->request->post()) && $model->validate()){
            $model->sendMail();

            Yii::$app->session->setFlash('success', '重置密码邮件已经发送到您的邮箱，请注意查收');
        }

        $this->layout = "main-login";
        
        return $this->render('find-password',['model'=>$model]);
    }

    public function actionResetPassword()
    {
        $token = Yii::$app->request->get('token');
        if(!$token){
            Yii::$app->session->setFlash('success', '重置密码链接已失效');
            $this->redirect(['/agent/account/login']);
        }

        $agent = Agent::findOne(['reset_password_token' => $token]);
        if(!$agent || time() - strtotime($agent->reset_password_send_date) > 3600){
            Yii::$app->session->setFlash('success', '重置密码链接已失效');
            $this->redirect(['/agent/account/login']);
        }

        $model = new ResetPasswordForm();
        
        if($model->load(Yii::$app->request->post()) && $model->validate()){
            $agent->password = Yii::$app->getSecurity()->generatePasswordHash($model->password);
            $agent->reset_password_token = null;
            $agent->save(true, ['password', 'reset_password_token']);
            Yii::$app->session->setFlash('success', '修改密码成功');

            $this->redirect(['/agent/account/login']);
        }

        $this->layout = "main-login";
        
        return $this->render('reset-password',['model'=>$model]);
    }
}
