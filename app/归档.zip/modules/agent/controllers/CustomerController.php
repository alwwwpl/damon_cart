<?php

namespace app\modules\agent\controllers;

use Yii;
use app\models\Customer;
use app\models\search\CustomerSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use app\models\Agent;

/**
 * CustomerController implements the CRUD actions for Customer model.
 */
class CustomerController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Customer models.
     * @return mixed
     */
    public function actionIndex()
    {
        $agent = Yii::$app->agent->identity;

        $searchModel = new CustomerSearch();

        if($agent->type==Agent::TYPE_PROVINCE){
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
            $query = $dataProvider->query;
            $query->joinWith('agent')->andWhere(['parent_id' => $agent->agent_id]);
        }else{
            $searchModel->agent_id = $agent->agent_id;
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        }

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
}
