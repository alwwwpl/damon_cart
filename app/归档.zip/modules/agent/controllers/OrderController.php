<?php

namespace app\modules\agent\controllers;

use Yii;
use app\models\Order;
use app\models\search\OrderSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use app\models\Agent;

/**
 * OrderController implements the CRUD actions for Order model.
 */
class OrderController extends Controller
{
    /**
     * Lists all Order models.
     * @return mixed
     */
    public function actionIndex()
    {
        $agent = Yii::$app->agent->identity;

        $searchModel = new OrderSearch();

        if($agent->type==Agent::TYPE_PROVINCE){
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
            $query = $dataProvider->query;
            $query->joinWith('customer')->leftJoin('oc_agent', 'oc_agent.agent_id=oc_customer.agent_id')->andWhere(['oc_agent.parent_id' => $agent->agent_id]);
        }else{
            $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
            $query = $dataProvider->query;
            $query->joinWith('customer')->andWhere(['agent_id' => $agent->agent_id]);
        }

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
}
