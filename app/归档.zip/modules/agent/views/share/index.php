<?php
use yii\helpers\Html;
use kartik\grid\GridView;

use app\models\InviteCode;

$this->title = "分享链接";
?>
    <?php if($count<=0){ ?>
    <div class="jumbotron">
        <?= Html::a('生成推广码', ['share/gen-codes'], ['class' => 'btn btn-default']) ?>
    </div>
    <? }else{ ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'responsive'=>true,
        'hover'=>true,
        'toolbar'=>[
            '{export}',
            '{toggleData}'
        ],
        'autoXlFormat'=>true,
        'export'=>[
            // 'fontAwesome'=>true,
            'showConfirmAlert'=>false,
            'target'=>GridView::TARGET_BLANK
        ],
        'panel'=>[
            'type'=>'primary',
        ],
        'columns' => [
            [
                'attribute' => 'code',
                'format' => 'text'
            ],
            [
                'attribute' => 'url',
                'format' => 'raw',
                'value' => function($model){
                    $url = $model->getUrl(Yii::$app->agent->identity);
                    return Html::a($url, $url, ['target' => '_blank']);
                }
            ],
            [
                'attribute' => 'status',
                'format' => 'text',
                'filter' => Html::activeDropDownList($searchModel, 'status', InviteCode::$statuses, ['class' => 'form-control','prompt' => '请选择']),
                'value' => function($model){
                    return $model->statusText;
                }
            ],
            [
                'attribute' => 'date_added',
                'format' => 'text'
            ],
            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    <?php } ?>
<?php 
$this->registerJsFile('/js/jquery.clipboard.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
$this->registerJsFile('/js/admin/share.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
?>