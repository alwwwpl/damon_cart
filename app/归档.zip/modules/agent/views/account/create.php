<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

use kartik\file\FileInput;
use kartik\depdrop\DepDrop;

use app\models\Area;

/* @var $this yii\web\View */
/* @var $model app\models\Agent */

$this->title = '代理商注册';
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css" media="screen">
h2{
    border-bottom: 1px solid #000;
}
</style>

<div class="agent-create">

    <h1 style="text-align: center;"><?= Html::encode($this->title) ?></h1>

    <div class="agent-form">

    <?php $form = ActiveForm::begin([
        'layout' => 'horizontal',
        'options'=>['enctype'=>'multipart/form-data'],
        'fieldConfig' => [
            'horizontalCssClasses' => [
                'wrapper' => 'col-sm-4'
            ]
        ]
    ]); ?>

    <?= $form->field($model, 'username')->textInput(['maxlength' => true])->hint('英文字母、数字、_的组合（此账号做为您登录账号是不可更改的）') ?>

    <?= $form->field($model, 'password')->passwordInput(['maxlength' => true])->hint('密码由6-16个字符组成，请使用英文加字母或符号的组合密码') ?>

    <h2>联系地址</h2>

    <div class="form-group required <?= $model->hasErrors('province_id') || $model->hasErrors('city_id') || $model->hasErrors('area_id') ? 'has-error' : '' ?>">
        <label class="control-label col-sm-3">区域</label>
        <div class="col-sm-6">
            <div class="row">
                <div class="col-sm-4">
                    <?= Html::activeDropDownList($model, 'province_id', 
                        ArrayHelper::map(Area::find()->where(['parent_id' => 1])->all(), 'area_id', 'area_name'), 
                        [
                            'class' => 'form-control',
                            'prompt' => '请选择...',
                        ]) 
                    ?>
                </div>

                <div class="col-sm-4">
                    <?= DepDrop::widget(
                        [
                            'model' => $model,
                            'attribute' => 'city_id',
                            'data' => ArrayHelper::map($model->province ? $model->province->children(1)->all() : [], 'area_id', 'area_name'),
                            'pluginOptions' => [
                                'depends' => ['agent-province_id'],
                                'placeholder' => '请选择...',
                                'url' => Url::to(['/area/options'])
                            ]
                        ]);
                    ?>
                </div>
                <div class="col-sm-4">
                    <?= DepDrop::widget(
                        [
                            'model' => $model,
                            'attribute' => 'area_id',
                            'data' => ArrayHelper::map($model->city ? $model->city->children(1)->all() : [], 'area_id', 'area_name'),
                            'pluginOptions' => [
                                'depends' => ['agent-city_id'],
                                'placeholder' => '请选择...',
                                'url' => Url::to(['/area/options'])
                            ]
                        ]) 
                    ?>
                </div>
            </div>

            <?= Html::error($model, 'province_id', ['class' => 'help-block help-block-error']) ?>
            <?= Html::error($model, 'city_id', ['class' => 'help-block help-block-error']) ?>
            <?= Html::error($model, 'area_id', ['class' => 'help-block help-block-error']) ?>
        </div>
    </div>

    <?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'phone')->textInput(['maxlength' => true])->hint('请填写你的电话号码，多个电话需空格分开') ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true])->hint('请正确填写电子邮箱，将用于找回密码、验证等') ?>

    <?= $form->field($model, 'contact')->textInput(['maxlength' => true])->hint('请填写您公司的联系人，多个联系人请用空格分开') ?>

    <?= $form->field($model, 'id_code')->textInput(['maxlength' => true])->hint('请如实填写身份证号，如验证失败无法通过申请') ?>

    <?= $form->field($model, 'file1', ['hintOptions' => ['hint' => '请上传jpg,png格式图片']])->widget(FileInput::classname(), [
        'options'=>['accept'=>'image/*'],
        'pluginOptions'=>[
            'allowedFileExtensions'=>['jpg','png'],
            'showUpload' => false
        ]
    ])->hint('请上传您的身份证，必须和所填写身份证号一致') ?>

    <?= $form->field($model, 'agent_city_id')->dropDownList(ArrayHelper::map($model->agentProvince->children(1)->all(), 'area_id', 'area_name'), ['prompt' => '请选择...', 'readonly' => true])
        ->hint('请选择要代理的市') ?>

    <?= $form->field($model, 'company_short_name')->textInput(['maxlength' => true])->hint('少于等于八个汉字') ?>

    <?= $form->field($model, 'company_name')->textInput(['maxlength' => true])->hint('请填写您公司营业执照，填写与营业执照不一致不通过审核') ?>

    <?= $form->field($model, 'business_license')->textInput(['maxlength' => true])->hint('如果您填写的注册号和上传营业执照号不符将不能开通') ?>

    <?= $form->field($model, 'file2', ['hintOptions' => ['hint' => '请上传jpg,png格式图片']])->widget(FileInput::classname(), [
        'options'=>['accept'=>'image/*'],
        'pluginOptions'=>[
            'allowedFileExtensions'=>['jpg','png'],
            'showUpload' => false
        ]
    ])->hint('请上传营业执原件或副本图片（格式JPG，小于2M的图片）') ?>

    <div class="jumbotron">
        <p style="font-size: 14px;">
        1.用 户 名：用于代理商登陆代理管理后台；<br/>
        2.密    码：请牢记密码，不要忘记，有问题请联系达蒙商城客服。<br/>
        3.所在地区：请选择您的所在地区，以方便定位您行使代理行为的区域。<br/>
        4.联系电话：请正确填写您的常用手机号码，该联系电话将直接用于密码找回和验证资质。<br/>
        5.电子邮箱：请正确填写您的常用邮箱，该邮箱将用于激活账号和验证账号安全。<br/>
        6.联 系 人：请准确填写代理商的真实姓名，用于认证和联系。<br/>
        7.身份证号：请正确填写联系人的身份证号，用于认证资质。<br/>
        8.身份证照：请上传小于2M的联系人扫描件，用于资质认证。<br/>
        9.代理区域：请选择您要代理的区域，省级代理之需选择到省，市级需要选择到市。<br/>
        10.企业信息：如实填写，该项省级代理商必须填写，其他选填。<br/>
        </p>
    </div>

    <div class="form-group">
        <div class="col-lg-offset-3 col-lg-4">
            <?= Html::submitButton('注册', ['class' => 'btn btn-success btn-block']) ?>
        </div>
    </div>

    <?php ActiveForm::end(); ?>

</div>

</div>
