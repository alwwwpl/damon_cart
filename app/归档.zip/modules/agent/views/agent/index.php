<?php

use yii\helpers\Html;
use kartik\grid\GridView;

use app\models\Agent;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\AgentSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Agents');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="agent-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'hover'=>true,
        'autoXlFormat'=>true,
        'export'=>[
            // 'fontAwesome'=>true,
            'showConfirmAlert'=>false,
            'target'=>GridView::TARGET_BLANK
        ],
        'panel'=>[
            'type'=>'primary',
        ],
        'columns' => [
            [
                'attribute' => 'agent_id',
                'headerOptions' => ['width' => '50'],
            ],
            'username',
            'phone',
            'email',
            'contact',
            'company_short_name',
            [
                'attribute' => 'customer_number',
                'value' => function($model){
                    return $model->getCustomers()->count();
                }
            ],
            [
                'attribute' => 'agent_area',
                'label' => '代理区域',
                'value' => function($model){
                    if($model->type==Agent::TYPE_PROVINCE){
                        return $model->agentProvince->area_name;
                    }else{
                        return $model->agentCity->area_name;
                    }
                }
            ],
            [
                'attribute' => 'status',
                'filter' => Html::activeDropDownList($searchModel, 'status', Agent::$statuses, ['class' => 'form-control','prompt' => '请选择']),
                'value'=>function ($model) {
                    return Agent::$statuses[$model->status];
                },
                'headerOptions' => ['width' => '100'],
            ],
            'date_added',
            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
