<?php
use yii\bootstrap\Nav;

use app\models\Agent;
?>
<aside class="main-sidebar">

    <section class="sidebar">
        <?
        $items = [
            ['label' => '首页', 'url' => ['/agent/default/index']],
            ['label' => '订单', 'url' => ['/agent/order/index']],
        ];
        if(!Yii::$app->agent->isGuest && Yii::$app->agent->identity->type==Agent::TYPE_PROVINCE){
            $items[] = ['label' => '市级代理', 'url' => ['/agent/agent/index']];
        }

        if(!Yii::$app->agent->isGuest && Yii::$app->agent->identity->type==Agent::TYPE_CITY){
            $items[] = ['label' => '从业人员', 'url' => ['/agent/customer/index']];
        }
        $items[] = ['label' => '推广', 'url' => ['/agent/share/index']];
        $items[] = ['label' => '个人信息', 'url' => ['/agent/user/update']];
        $items[] = ['label' => '修改密码', 'url' => ['/agent/user/change-password']];
        echo Nav::widget(
            [
                'encodeLabels' => false,
                'options' => ['class' => 'sidebar-menu'],
                'items' => $items,
            ]
        );
        ?>
    </section>

</aside>
