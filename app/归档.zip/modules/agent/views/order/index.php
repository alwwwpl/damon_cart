<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\LinkPager;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\AgentSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Orders');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="box">
    <div class="box-body">
        <table class="table table-bordered table-striped dataTable">
            <thead>
                <tr>
                    <th>编号</th>
                    <th>收货地</th>
                    <th>支付方式</th>
                    <th>总价</th>
                    <th>下单时间</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dataProvider->models as $model) { ?>
                <tr>
                    <td><?= $model->order_id; ?></td>
                    <td><?= $model->shipping_city; ?></td>
                    <td><?= $model->payment_method; ?></td>
                    <td><?= $model->total; ?></td>
                    <td><?= $model->date_added; ?></td>
                </tr>
                <tr>
                    <td colspan="5">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width:30%">图片</th>
                                    <th>名称</th>
                                    <th>价格</th>
                                    <th>数量</th>
                                    <th>总价</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($model->orderProducts as $orderProduct): ?>
                                <tr>
                                    <td><?= Html::img($orderProduct->product->imageUrl, ['width' => 200]) ?></td>
                                    <td><?= $orderProduct->name ?></td>
                                    <td><?= $orderProduct->price ?></td>
                                    <td><?= $orderProduct->quantity ?></td>
                                    <td><?= $orderProduct->total ?></td>
                                </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <?= LinkPager::widget(['pagination' => $dataProvider->pagination]); ?>
    </div>
</div>
