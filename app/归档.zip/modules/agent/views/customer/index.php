<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\AgentSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Customers');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="agent-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'customer_id',
            [
                'attribute' => 'telephone',
                'value' => function($model){
                    return $model->telephoneHiden;
                }
            ],
            [
                'attribute' => 'email',
                'value' => function($model){
                    return $model->emailHiden;
                }
            ],
            [
                'attribute' => 'customerUserNumer',
                'label' => '小C数量',
                'value' => function($model){
                    return $model->getCustomerUsers()->count();
                }
            ],
            'date_added',
            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
