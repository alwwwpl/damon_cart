<?php
use yii\helpers\Html;
?>

<?= Html::a('忘记密码', $url) ?>